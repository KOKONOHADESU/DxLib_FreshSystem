#pragma once

#include <string>

/// <summary>
/// CSV�֘A
/// </summary>
namespace CSV
{
	// �g���q
	const std::string kExtension = ".csv";
}